*********************************************************
*  Product: Intel(R) Chipset Software Installation Utility
*  Release: Production Version
*  Version: 5.0.1.1015
*  Target Chipset#: Intel(R) 82865 G/PE/P, Intel(R) 82875P
*  Date: April 22, 2003 
*********************************************************

#: For the list of supported chipsets, please refer to the Release Notes

*********************************************************
*  CONTENTS OF THIS DOCUMENT
*********************************************************
This document contains the following sections:

1.  Overview
2.  System Requirements
3.  Contents of the Distribution Package
4.  List of Available Command Line Flag Options 
5.  Contents of the Extracted Files
6.  Installing the Software in Interactive Mode
7.  Installing the Software in Silent Mode
8.  Installing the INF Files Prior to OS Installation
    8A. Installing the Windows* XP INF Files Prior
        to OS Installation
    8B. Installing the Windows* 2000 INF Files Prior
        to OS Installation
    8C. Installing the Windows* 98SE/Windows* Me 
        INF Files Prior to OS Installation
    8D. Installing the Windows* Server 2003 INF Files 
	Prior to OS Installation
9.  Installing the INF Files After OS Installation
    9A. Installing the Windows* XP INF Files after
        OS Installation 
    9B. Installing the Windows* 2000 INF Files after
        OS Installation
    9C. Installing the Windows* 98SE/Windows* Me INF Files 
        after OS Installation
    9D. Installing the Windows* Server 2003 INF Files after
        OS Installation
10. Verifying Installation of the Software and 
    identifying the Software Version Number
11. Troubleshooting


************************************************************
* 1.  OVERVIEW
************************************************************
The Intel(R) Chipset Software Installation Utility installs
to the target system the Windows* INF files that outline to 
the operating system how the Intel(R) chipset components will 
be configured.  This is needed for the proper functioning of
the following features:

   - Core PCI and ISAPNP Services
   - AGP Support
   - IDE/ATA33/ATA66/ATA100 Storage Support
   - SATA Storage Support
   - USB Support
   - Identification of Intel(R) chipset components in 
     the Device Manager

This software can be installed in three modes: Interactive,
Silent and Unattended Preload.  The Interactive Mode 
requires user input during installation; the Silent Mode and
Unattended Preload do not.  

Additionally, this software offers a set of command line
flag options that enables extended installation functionality. 
The command line flags are not case sensitive.  See Section 4 
for detailed descriptions of these flags.

Important Note:
The Intel(R) Chipset Software Installation Utility is 
distributed in two formats -- self extracting .EXE files
(INFINST_xxx.EXE) or compressed .ZIP files (INFINST_xxx.ZIP). 
Depending on which distribution format is being executed, 
the command-line syntax may differ. See Section 4 for more details. 


************************************************************
* 2.  SYSTEM REQUIREMENTS 
************************************************************
1.  The software included with this distribution package is 
    designed to operate with the following chipset 
    configurations:
    
Note: Please refer to the release notes for the list of supported chipsets.
      
              
2.  One of the following operating systems must be 
    fully installed and running on the system
    before installing this software:


    Windows* 98SE	  4.10.2222  (Original Release)
    Windows* Me		  4.90.3000  (Original Release)
    Windows* 2000	  5.00.2195  (Original Release)
    Windows* XP		  5.10.2600  (Original Release)
    Windows* Server 2003  5.20.3790  (Original Release)


    To verify which operating system has been installed onto 
    the target system, follow the steps below:

    a.  Click on Start.
    b.  Select Settings.
    c.  Select Control Panel.
    d.  Double-click on the System icon.
    e.  Click on the General system properties tab.
    f.  Verify, which OS has been installed by reading
        the System information.
                              
3.  It is recommended that the software be installed on 
    systems with at least 32MB of system memory when using 
    Windows* 98SE and Windows* Me. Windows* 2000 and Windows* XP
    require at least 64MB of system memory.


4.  It is recommended that there be a minimum of 5MB of hard
    disk space on the system in order to install this software.

5.  Check the System Requirements.  The operating system 
    must be fully installed and running on the system before
    running this software.

6.  Close any running applications.  Otherwise, you may
    experience difficulties.

7.  It is recommended that the Intel(R) Chipset Software 
    Installation Utility be installed onto the target system 
    prior to the installation of other drivers.


Please check with your system provider to determine which 
operating system and Intel(R) chipset are used in your system.


************************************************************
* 3.  CONTENTS OF THE DISTRIBUTION PACKAGE
************************************************************
The Intel(R) Chipset Software Installation Utility package 
contains the following items:

    File(s)       
    -------
    INFINST_xxx.EXE -or- INFINST_xxx.ZIP
    README.TXT, RELEASE_xxx.HTM

   *** NOTE:  Only the files that reference the currently 
              detected devices are copied to the system.
	      
              If the -A option is exercised, the files are
              not copied to the <Windows>\INF directory.
              See Section 4 for more information.  

                                       
************************************************************
* 4.  LIST OF AVAILABLE COMMAND LINE FLAG OPTIONS
************************************************************
The Intel(R) Chipset Software Installation Utility supports  
several command line flags for various installation options. 
All command line flags and parameters must be separated by a 
space, except for the language code after the '-L' flag.

Due to the different distribution formats available for the
Intel(R) Chipset Software Installation Utility, the command
line flag syntax may vary:

1. Self-Extracting .EXE Distribution:
      When installing this software using the .EXE 
      distribution, an extra '-A' must be appended to the 
      INFINST_xxx.EXE program call (i.e. INFINST_ENU.EXE -A) 
      in order to successfully pass command line parameters.

   Note: The extra '-A' flag for the self-extracting .EXE 
         package is DIFFERENT from the '-A' command line flag 
         option described below, under Compressed .ZIP
         Distribution.        

      Example: To extract INF files using the '-A' flag 
               described below, the installation program 
               should be invoked as follows:  
          
               INFINST_ENU.EXE -A -A (optional -P)

2. Compressed .ZIP Distribution:
      When installing this software using the .ZIP 
      distribution, there is no need to append any extra 
      flags to the SETUP.EXE program call in order to pass 
      command line flags.

      Example: To extract INF files using the '-A' flag 
               described below, the installation program 
               should be invoked as follows:  
                        
               SETUP.EXE -A (optional -P)

Below is a list of all the available command line flags that
may be used with the program call.  Note that the '-L' and 
the '-S' flags MUST be specified at the end of the command 
line flag list.

Flag            Description
----            -----------
-?              Help flag.  Displays the list of available 
                command line flags.  This parameter works in 
                the Interactive Mode only.  

-A              Extracts the INF files and README.TXT to 
                either "C:\Program Files\Intel\InfInst" or 
                the <Installation Path> directory specified 
                using the '-P' flag. The software will 
                NOT install these INF files to the system.  
                This flag can be combined only with the '-P' 
                flag option. All other options will be 
                ignored if the '-A' flag is specified. 
                This parameter works in either Silent Mode 
                or Interactive Mode.

-B              Automatically reboots the system after 
                installation. This flag is ignored if '-A' 
                flag is specified. This parameter works in 
                either Silent Mode or Interactive Mode.

-H<mode>
                This flag enables DMA Mode for an IDE device.

-L<LangCode>
                Forces the InstallShield* user interface to 
                display the specified language during setup.  
                Note that there should be NO spaces between 
                '-L' and the 4-digit language code (see 
                below). This flag and the '-S' flag must be 
                placed at the end of the command line flag 
                list. This parameter works in Interactive 
                Mode only.

-NOLIC
                This flag disables the license agreement
                dialogue box during installation. This parameter 
                works in Interactive Mode only.

-NOREAD
                This flag disables the readme display during
                installation. This parameter works in Interactive
                Mode only.

-NOWEL
                This flag disables the welcome screen during
                installation. This parameter works in the
                Interactive Mode only.

-OVER ALL	
		This flag will update ALL INF drivers even if
		third party drivers are currently installed. This
		parameter works in Interactive Mode only.

-OVER FWH
		This flag will update the Security drivers even
		if a third party Security driver is currently
		installed. This parameter works in Interactive
		Mode only.

-OVER IDE	
		This flag will update the Storage drivers even
		if a third party Storage driver is currently
		installed. This parameter works in Interactive
		Mode only.

-OVER SMB	
		This flag will update the LAN drivers even if
		thrid party LAN drivers are currently installed.
		This parameter works in Interactive Mode only.

-P <Installation Path>   
                Specifies the HDD location to which the INF 
                program files are copied.  If this flag is 
                not specified at the command line, the 
                <Installation Path> directory is by default 
                assumed to be:
                
                   C:\Program Files\Intel\INFInst
                
                If this flag is used without the '-A' 
                option, only README.TXT will be copied to 
                <Installation Path>.  The directory name can 
                include spaces.  In this case, however, a 
                pair of double quotes (") must enclose the 
                directory name.  This parameter works in 
                either Silent Mode or Interactive Mode.

-S              Runs the Installer in Silent Mode.  No user 
                interface is displayed. This flag and the
                '-L' flag must be placed at the end of the 
                command line flag list.
                
-SKIP<DevID>
                This flag will allow one or more devices to
                not be installed.


Below are the language codes used with the '-L' flag:

    Language         		<LangCode>
    --------         		----------
    Chinese (Simplified)  	0804    
    Chinese (Traditional) 	0404
    Czech             		0005
    Danish            		0006
    Dutch              		0013
    English (United States)	0009
    Finnish            		000B
    French (Canada)     	0C0C
    French (Standard)     	040C
    German            		0007
    Greek              		0008
    Hungarian         		000E
    Italian            		0010
    Japanese           		0011
    Korean             		0012
    Norwegian          		0014
    Polish            		0015
    Portuguese (Brazil)	  	0416
    Portuguese (Standard) 	0816
    Russian            		0019
    Spanish           		000A
    Swedish               	001D
    Thai               		001E
    Turkish            		001F


************************************************************
* 5.  CONTENTS OF THE EXTRACTED FILES
************************************************************
INF files are copied to the hard disk drive after running 
the Intel(R) Chipset Software Installation Utility 
executable with a '-A' flag (i.e., "INFINST_ENU.EXE -A -A" 
or "SETUP.EXE -A").  The location of the INF files depends
on whether a '-P' flag is specified along with the '-A' 
flag:

1.  If a '-P' flag is NOT specified, then the INF files are 
    copied to the following directory:  
       "C:\Program Files\Intel\INFINST"
2.  If a '-P' flag IS specified, then the INF files are 
    copied to the location listed immediately after the 
    '-P' flag.  

    See Section 4 for more information on flag usage.

After INF file extraction, the INF files and components are 
copied to the <INF Extract Directory>.  These files and 
components are categorized according to the Intel(R) 
Chipset types. The following table summarizes the locations
of the INF files, by chipsets:

   NOTE: The INF files are designed to update ONLY devices
         not supported by the corresponding operating 
         systems.

   NOTE: "<INF Extract Directory>" is abbreviated "<IED>"
         in the remainder of this section.

For each subdirectory of <IED> (e.g., ICH, ICH2, etc), 
the INF files are further classified according to 
the operating systems they are designed for:

   Win98SE\   --->  Contains INF files designed for
                     Windows* 98SE ONLY.
   Win2000\   --->  Contains INF files designed for
                     Windows* 2000 ONLY.
   WinME\     --->  Contains INF files designed for
                     Windows* Me ONLY.
   WinXP\     --->  Contains INF files designed for
                     Windows* XP ONLY.
   Win2003\   --->  Contains INF files designed for
                     Windows* Server 2003 ONLY.

NOTES:							 
1.  INFPrelo.INF makes a CUSTOM.INF template that installs 
    the INF files for Intel(R) chipsets during OS setup.  
    OEMs can incorporate this file into the SETUP directory 
    for the OEM Preload Kit.
    (Refer to Section 8 for more details.)


************************************************************
* 6.  INSTALLING THE SOFTWARE IN INTERACTIVE MODE
************************************************************
1.  Verify that all system requirements have been met as 
    described in section 2.

2.  Run the InstallShield* installation program:
       Self-extracting .EXE distribution: INFINST_xxx.EXE
       Compressed .ZIP distribution: SETUP.EXE

3.  You will be prompted to agree to the license agreement.  
    If you do not agree, the Installer will exit before 
    extracting any files.
    
4.  Follow the on-screen instructions and use the default
    settings to complete the setup, once the operating
    system has rebooted.

5.  This completes the installation of the Intel(R) Chipset 
    Software Installation Utility.  


************************************************************
* 7.  INSTALLING THE SOFTWARE IN SILENT MODE
************************************************************
1.  Verify that all system requirements have been met as 
    described in section 2.

2.  Run the InstallShield* installation program:
    For silent install with auto-reboot:
       Self-extracting .EXE distribution: 
       INFINST_xxx.EXE -a -b -s
       Compressed .ZIP distribution:
       SETUP.EXE -b -s
    - OR -
    For silent install without auto-reboot:
       Self-extracting .EXE distribution: 
       INFINST_xxx.EXE -a -s
       Compressed .ZIP distribution: SETUP.EXE -s

3.  The utility will perform the necessary updates and 
    record the installation status in the following system 
    registry key:
        HKEY_LOCAL_MACHINE\Software\Intel\INFInst

4.  If the utility was invoked with the "-b" flag, the 
    system will automatically reboot if the update was
    successful.

    NOTE:  The system MUST be rebooted for all device 
    updates to take effect.

5.  To determine whether the install was successful, verify 
    the "install" value in the registry key specified in 
    Step 3.

6.  In Silent Mode the utility will not display the license
    agreement. When using Silent Mode the license agreement,
    license.txt, will be placed in the following folder:
        Program Files/Intel/INFInst folder.
    Please read this agreement.

    The following table describes the various parameters:

	Name		Type	Data		Description
	-----		----	----		-----------
	"install"      	String 	"success"      	The installation was 
						successful.

				"fail"		The installation was 
						not successful.
						No INF files were 
						copied to the system.

       	"reboot"       	String	"Yes"		A reboot is required to 
						complete the installation.

				"No"		No reboot is required 
						to complete the 
						installation.

       	"version"      	String 	<varies>       	Current version number 
						of the Intel(R) Chipset 
						Software Installation 
						Utility


************************************************************
* 8.  INSTALLING THE INF FILES PRIOR TO OS INSTALLATION
************************************************************
1.  Copy the OS installation files from the setup 
    directory to a directory on the hard disk. This 
    procedure requires a minimum of 5MB of hard disk space.
    It is important to make sure there is enough disk space 
    before beginning the copy process. This can be done by
    opening 'My Computer' and then right clicking on the
    correct drive and selecting 'Properties'. The
    directories shall be referred to as follows:

      Windows* XP   :  <WINXP Setup Directory>
      Windows* 2000 :  <WIN2000 Setup Directory>
      Windows* 98SE :  <WIN98SE Setup Directory>
      Windows* Me   :  <WINMe Setup Directory>
      Windows* 2003 :  <WIN2003 Setup Directory>
        

************************************************************
* 8A.  INSTALLING THE WINDOWS* XP INF FILES PRIOR TO
*      OS INSTALLATION
************************************************************
NOTE: The Windows* XP OEM Preload Kit distribution CD
      contains a setup directory with all the base OS setup
      files and installation programs (WINNT.EXE and
      WINNT32.EXE).  

The name of the directory may vary depending on the 
distribution CD (e.g., \I386\).


1.  Create the following directory structure under the 
    <WINXP Setup Directory>: 

       \$OEM$\$$\INF

2.  Copy the Windows* XP INF files from 
    <INF Extract Directory>\XXXX\WinXP to the directory
    created in Step 1 above:

       <WINXP Setup Directory>\$OEM$\$$\INF

    Note: XXXX is the directory name for the chipset of 
          interest.  See Section 8 for more details.

3.  Create the following directory structure under the 
    <WINXP Setup Directory>: 

       \$OEM$\$1\drivers\IntelINF

4.  Copy the Windows* XP INF files AND the catalog files 
    (.CAT) from <INF Extract Directory>\XXXX\WinXP to the 
    directory created in Step 4 above:

       <WINXP Setup Directory>\$OEM$\$1\drivers\IntelINF

    Note: XXXX is the directory name for the chipset of 
          interest.  See Section 8 for more details.

5.  Either modify the default Windows* XP installation
    answer file, UNATTEND.TXT, located in <WINXP Setup 
    Directory>, or create a customized answer file.  The
    answer file must include the following information:
   
       [Unattended]
       OemPreinstall = Yes
       OemPnPDriversPath="drivers\IntelINF"

    A sample answer file for preloading the Intel(R) Chipset
    Software Installation utility files is available: 
    <INF Extract Directory>\XXXX\WinXP\INFAnswr.TXT
    
    For more information about Windows* XP answer files 
    and unattended installations, please refer to the 
    Microsoft* Windows* XP Guide to Unattended Setup.  For
    more information about the \$OEM$ folder, see the 
    Microsoft Windows* XP OEM Preinstallation Kit (OPK) 
    User Guide, if you are a computer manufacturer. 
    Otherwise, see the Microsoft Windows* XP Deployment 
    Guide.

6.  Run "WINNT.EXE /u:<answer file name> /s:<WINXP Setup 
    Directory>" to install Windows* XP.

************************************************************
* 8B.  INSTALLING THE WINDOWS* 2000 INF FILES PRIOR TO
*      OS INSTALLATION
************************************************************
NOTE: The Windows* 2000 OEM Preload Kit distribution CD
      contains a setup directory with all the base OS setup
      files and installation programs (WINNT.EXE and
      WINNT32.EXE).  

The name of the directory may vary depending on the 
distribution CD (e.g., \I386\).


1.  Create the following directory structure under the 
    <WIN2000 Setup Directory>: 

       \$OEM$\$$\INF

2.  Copy the Windows* 2000 INF files from 
    <INF Extract Directory>\XXXX\Win2000 to the directory
    created in Step 1 above:

       <WIN2000 Setup Directory>\$OEM$\$$\INF

    Note: XXXX is the directory name for the chipset of 
          interest.  See Section 8 for more details.

3.  Create the following directory structure under the 
    <WIN2000 Setup Directory>: 

       \$OEM$\$1\drivers\IntelINF

4.  Copy the Windows* 2000 INF files AND the catalog files 
    (.CAT) from <INF Extract Directory>\XXXX\Win2000 to the 
    directory created in Step 4 above:

       <WIN2000 Setup Directory>\$OEM$\$1\drivers\IntelINF

    Note: XXXX is the directory name for the chipset of 
          interest.  See Section 8 for more details.

5.  Either modify the default Windows* 2000 installation
    answer file, UNATTEND.TXT, located in <WIN2000 Setup 
    Directory>, or create a customized answer file.  The
    answer file must include the following information:
   
       [Unattended]
       OemPreinstall = Yes
       OemPnPDriversPath="drivers\IntelINF"

    A sample answer file for preloading the Intel(R) Chipset
    Software Installation utility files is available: 
    <INF Extract Directory>\XXXX\Win2000\INFAnswr.TXT
    
    For more information about Windows* 2000 answer files 
    and unattended installations, please refer to the 
    Microsoft* Windows* 2000 Guide to Unattended Setup.  For
    more information about the \$OEM$ folder, see the 
    Microsoft Windows* 2000 OEM Preinstallation Kit (OPK) 
    User Guide, if you are a computer manufacturer. 
    Otherwise, see the Microsoft Windows* 2000 Deployment 
    Guide.

6.  Run "WINNT.EXE /u:<answer file name> /s:<WIN2000 Setup 
    Directory>" to install Windows* 2000.


************************************************************
* 8C.  INSTALLING THE Windows* 98SE/WINDOWS* Me 
*      INF FILES PRIOR TO OS INSTALLATION
************************************************************
NOTE: The Windows* 98SE or Windows* Me OEM 
      Preload Kit distribution CD contains a setup directory 
      with all the base OS setup files (*.CAB) and the 
      installation program (SETUP.EXE).

The name of the directory may vary depending on the 
distribution CD (e.g., \WIN98SE\).   

1.  Copy the Windows* 98SE INF files from
    <INF Extract Directory>\XXXX\Win98SE to the setup 
    directory identified in Step 1 above, if you are 
    preloading Windows* 98SE.
       -or-
    Copy the Windows* Me INF files from
    <INF Extract Directory>\XXXX\WinME to the setup 
    directory identified, if you are preloading Windows* Me.  
    
    Note: XXXX is the directory name for the chipset of 
          interest.  See Section 8 for more details.

3.  Run SETUP.EXE to install Windows* 98SE or Windows* Me.

************************************************************
* 8D.  INSTALLING THE WINDOWS* Server 2003 INF FILES PRIOR 
*      TO OS INSTALLATION
************************************************************
NOTE: The Windows* Server 2003 OEM Preload Kit distribution 
      CD contains a setup directory with all the base OS 
      setup files and installation programs (WINNT.EXE and
      WINNT32.EXE).  

The name of the directory may vary depending on the 
distribution CD (e.g., \I386\).


1.  Create the following directory structure under the 
    <WIN2003 Setup Directory>: 

       \$OEM$\$$\INF

2.  Copy the Windows* Server 2003 INF files from 
    <INF Extract Directory>\XXXX\Win2003 to the directory
    created in Step 1 above:

       <WIN2003 Setup Directory>\$OEM$\$$\INF

    Note: XXXX is the directory name for the chipset of 
          interest.  See Section 8 for more details.

3.  Create the following directory structure under the 
    <WIN2003 Setup Directory>: 

       \$OEM$\$1\drivers\IntelINF

4.  Copy the Windows* Server 2003 INF files AND the catalog 
    files (.CAT) from <INF Extract Directory>\XXXX\Win2003 
    to the directory created in Step 4 above:

       <WIN2003 Setup Directory>\$OEM$\$1\drivers\IntelINF

    Note: XXXX is the directory name for the chipset of 
          interest.  See Section 8 for more details.

5.  Either modify the default Windows* Server 2003 installation
    answer file, UNATTEND.TXT, located in <WIN2000 Setup 
    Directory>, or create a customized answer file.  The
    answer file must include the following information:
   
       [Unattended]
       OemPreinstall = Yes
       OemPnPDriversPath="drivers\IntelINF"

    A sample answer file for preloading the Intel(R) Chipset
    Software Installation utility files is available: 
    <INF Extract Directory>\XXXX\Win2003\INFAnswr.TXT
    
    For more information about Windows* Server 2003 answer 
    files and unattended installations, please refer to the 
    Microsoft* Windows* Server 2003 Guide to Unattended Setup.
    For more information about the \$OEM$ folder, see the 
    Microsoft Windows* Server 2003 OEM Preinstallation Kit 
    (OPK) User Guide, if you are a computer manufacturer. 
    Otherwise, see the Microsoft Windows* Server 2003 
    Deployment Guide.

6.  Run "WINNT.EXE /u:<answer file name> /s:<WIN2003 Setup 
    Directory>" to install Windows* 2000.


************************************************************
* 9.  INSTALLING THE INF FILES AFTER OS INSTALLATION
************************************************************

************************************************************
* 9A.  INSTALLING THE WINDOWS* XP INF FILES AFTER OS 
*      INSTALLATION
************************************************************
Some Intel(R) chipset platforms already are supported by 
Windows* XP so it may not be necessary to use the INF 
files provided by this software to update Windows* XP.

The following steps describe the installation process of
the Windows* XP INF files.  You may need to repeat these 
steps to update all Intel(R) chipset devices not supported
by Windows* XP.

    1.  Copy the contents of the 
        <INF Extract Directory>\XXXX\WinXP 
        directory to the root directory of the floppy disk
        (A:\).
        
        Note: XXXX is the directory name for the chipset 
              of interest. See Section 8 for more details.
              
    2.  Close all programs currently running on the system.
    3.  Click on Start.
    4.  Select Settings.
    5.  Select Control Panel.
    6.  Double-click on System icon.
    7.  Click on Hardware tab.
    8.  Click on Device Manager button.
    9.  Select "Devices by connection" under the View menu.
    10. Click on MPS Uniprocessor PC -OR- MPS 
        Multiprocessor PC.
        NOTE:  Only one of the above items will be 
               displayed for a given system.
    11. Click on PCI bus.
    12. Right-click on the line containing the description
            PCI standard host CPU bridge
            -or-
            PCI standard ISA bridge
            -or-
            PCI standard PCI-to-PCI bridge
            -or- 
            PCI System Management Bus
            -or- 
            Standard Dual PCI IDE Controller
            -or-
            Standard Universal PCI to USB Host Controller
            (This line will be selected.)
    13. Select Properties from the pull-down menu.
    14. Click on the Driver tab.
    15. Click on Update Driver button.
    16. Windows* XP will launch the Upgrade Device Driver 
        Wizard.  Select Next.
    17. Ensure that the following choice is selected:
            Search for a suitable driver for my device 
            (recommended)
    18. Insert the floppy containing the Windows* XP INF 
        files into the floppy drive.
    19. Select Next.
    20. Windows* XP will list locations from where the 
        updated driver file can be found.  Ensure that the 
        following choice is selected:
            Floppy disk drives
    21. Select Next.
    22. Windows* XP should report that a driver has been
        found:
            (The detected device name will be displayed.)
        Select Next.            
    23. Select Finish.
    24. Restart the system when prompted to do so.


************************************************************
* 9B.  INSTALLING THE WINDOWS* 2000 INF FILES AFTER OS 
*      INSTALLATION
************************************************************
Some Intel(R) chipset platforms already are supported by 
Windows* 2000, so it may not be necessary to use the INF 
files provided by this software to update Windows* 2000.

The following steps describe the installation process of
the Windows* 2000 INF files.  You may need to repeat these 
steps to update all Intel(R) chipset devices not supported
by Windows* 2000.

    1.  Copy the contents of the 
        <INF Extract Directory>\XXXX\Win2000 
        directory to the root directory of the floppy disk
        (A:\).
        
        Note: XXXX is the directory name for the chipset 
              of interest. See Section 8 for more details.
              
    2.  Close all programs currently running on the system.
    3.  Click on Start.
    4.  Select Settings.
    5.  Select Control Panel.
    6.  Double-click on System icon.
    7.  Click on Hardware tab.
    8.  Click on Device Manager button.
    9.  Select "Devices by connection" under the View menu.
    10. Click on MPS Uniprocessor PC -OR- MPS 
        Multiprocessor PC.
        NOTE:  Only one of the above items will be 
               displayed for a given system.
    11. Click on PCI bus.
    12. Right-click on the line containing the description
            PCI standard host CPU bridge
            -or-
            PCI standard ISA bridge
            -or-
            PCI standard PCI-to-PCI bridge
            -or- 
            PCI System Management Bus
            -or- 
            Standard Dual PCI IDE Controller
            -or-
            Standard Universal PCI to USB Host Controller
            (This line will be selected.)
    13. Select Properties from the pull-down menu.
    14. Click on the Driver tab.
    15. Click on Update Driver button.
    16. Windows* 2000 will launch the Upgrade Device Driver 
        Wizard.  Select Next.
    17. Ensure that the following choice is selected:
            Search for a suitable driver for my device 
            (recommended)
    18. Insert the floppy containing the Windows* 2000 INF 
        files into the floppy drive.
    19. Select Next.
    20. Windows* 2000 will list locations from where the 
        updated driver file can be found.  Ensure that the 
        following choice is selected:
            Floppy disk drives
    21. Select Next.
    22. Windows* 2000 should report that a driver has been
        found:
            (The detected device name will be displayed.)
        Select Next.            
    23. Select Finish.
    24. Restart the system when prompted to do so.


************************************************************
* 9C.  INSTALLING THE Windows* 98SE/WINDOWS* 
*      Me INF FILES AFTER OS INSTALLATION
************************************************************
Some Intel(R) chipset platforms already are supported by 
Windows* 98SE and Windows* Me, so it may not be 
necessary to use the INF files provided by this software to 
update these operating systems.

The following steps describe the installation process for
the Windows* 98 Second Edition and Windows* Me INF files.  
You may need to repeat these steps to update all Intel(R) 
chipset devices not supported by these operating systems.

    1.  Depending on the operating system you intend to 
        update, copy the contents of one of the following 
        directories to the root directory of the floppy 
        disk (A:\).

       For Windows* 98SE: 
                 <INF Extract Directory>\XXXX\Win98SE
       For Windows* Me: 
                 <INF Extract Directory>\XXXX\WinME
     
        Note: XXXX is the directory name for the chipset of
              interest. See Section 8 for more details.
              
    2.  Close all programs currently running on the system.
    3.  Click on Start.
    4.  Select Settings.
    5.  Select Control Panel.
    6.  Double click on System icon.
    7.  Click on Device Manager tab.
    8.  Click on View Devices by Connection button.
    9.  Click on Plug and Play BIOS, or Advanced Configuration
        and Power Interface (ACPI) BIOS.
        NOTE:  Only one of the above items will be 
               displayed for a given system.
    10. Click on PCI bus.
    11. Click on the line containing the description
            PCI standard host CPU bridge
            -or-
            PCI standard ISA bridge
            -or-
            PCI standard PCI-to-PCI bridge
            -or- 
            PCI System Management Bus
            -or- 
            Standard Dual PCI IDE Controller
            -or-
            Standard Universal PCI to USB Host Controller
            (This line will be selected.)
    12. Click on the Remove button at the bottom of the 
        window.
    13. If more than one Intel(R) chipset device needs 
        updating, go to Step 11 to remove more devices.
    14. When prompted to restart the system, select Yes.
    15. Restart the system.
    16. The Windows operating system will launch the Add
        New Hardware Wizard.
        Select Next in the dialog box that states:
            "This wizard searches for new drivers for:"
    17. Ensure that the following choice is selected:
            Search for the best driver for your device 
            (Recommended)
    18. Select Next.
    19. Insert the floppy containing the .INF files into
        the floppy drive.
    20. Ensure that the following choice is selected:
            Floppy disk drives
    21. If the .INF files are not located in the root 
        directory of the floppy disk, also select the 
        following and enter the path to the .INF files
        needed to update this operating system:
            Specify a location:
    22. Select Next.
    23. The Windows operating system should report that
        the driver has been found and that it is "now 
        ready to install the best driver for this 
        device."
    24. Select Next.
    25. Select Finish.
    26. The Windows operating system may prompt you to 
        install additional drivers if more than one device
        was removed during Steps 11 through 13. Follow the 
        same procedure to install the remaining Intel(R) 
        chipset devices.
    27. Restart the system when prompted to do so.


************************************************************
* 9D.  INSTALLING THE WINDOWS* Server 2003 INF FILES AFTER 
*      OS INSTALLATION
************************************************************
Some Intel(R) chipset platforms already are supported by 
Windows* Server 2003 so it may not be necessary to use the INF 
files provided by this software to update Windows* Server 2003.

The following steps describe the installation process of
the Windows* XP INF files.  You may need to repeat these 
steps to update all Intel(R) chipset devices not supported
by Windows* Server 2003.

    1.  Copy the contents of the 
        <INF Extract Directory>\XXXX\Win2003
        directory to the root directory of the floppy disk
        (A:\).
        
        Note: XXXX is the directory name for the chipset 
              of interest. See Section 8 for more details.
              
    2.  Close all programs currently running on the system.
    3.  Click on Start.
    4.  Select Settings.
    5.  Select Control Panel.
    6.  Double-click on System icon.
    7.  Click on Hardware tab.
    8.  Click on Device Manager button.
    9.  Select "Devices by connection" under the View menu.
    10. Click on MPS Uniprocessor PC -OR- MPS 
        Multiprocessor PC.
        NOTE:  Only one of the above items will be 
               displayed for a given system.
    11. Click on PCI bus.
    12. Right-click on the line containing the description
            PCI standard host CPU bridge
            -or-
            PCI standard ISA bridge
            -or-
            PCI standard PCI-to-PCI bridge
            -or- 
            PCI System Management Bus
            -or- 
            Standard Dual PCI IDE Controller
            -or-
            Standard Universal PCI to USB Host Controller
            (This line will be selected.)
    13. Select Properties from the pull-down menu.
    14. Click on the Driver tab.
    15. Click on Update Driver button.
    16. Windows* Server 2003 will launch the Upgrade Device Driver 
        Wizard.  Select Next.
    17. Ensure that the following choice is selected:
            Search for a suitable driver for my device 
            (recommended)
    18. Insert the floppy containing the Windows* Server 2003 
	INF files into the floppy drive.
    19. Select Next.
    20. Windows* Server 2003 will list locations from where the 
        updated driver file can be found.  Ensure that the 
        following choice is selected:
            Floppy disk drives
    21. Select Next.
    22. Windows* Server 2003 should report that a driver has 
	been found:
            (The detected device name will be displayed.)
        Select Next.            
    23. Select Finish.
    24. Restart the system when prompted to do so.


************************************************************
* 10.  VERIFYING INSTALLATION OF THE SOFTWARE AND
       IDENTIFYING THE SOFTWARE VERSION NUMBER
************************************************************

The version of the software included in the distribution 
package can be identified by examining the following 
registry location:

    Key name:   \\HKEY_LOCAL_MACHINE\Software\Intel\InfInst
    Value name: version


************************************************************
* 11.  TROUBLESHOOTING
************************************************************
It is assumed that the system requirements in Section 2 
above have been satisfied.

Issue:      System locks up during Device Manager Remove or 
            during restart.

Solution:   System lockup can occur during Restart as a 
            result of several possible system issues.  In 
            the event of system lockup, restart the machine 
            and view Device Manager.  If devices are listed 
            properly and the system experiences no further 
            problems, then the .INF file restore process was 
            successful.  If devices are not configured 
            correctly, try re-running the procedures 
            outlined in Section 3.

            If this does not fix the issue or further 
            issues are experienced, reinstall the 
            operating system.


Issue:      After running the setup program and rebooting 
            the machine, Windows reports that it cannot find 
            one of the following files:
                  ESDI_506.pdr

Solution:   Click Browse in the dialog box where this 
            issue occurs, locate the

                  <Windows>\System\IOSubsys

            directory and click OK. The system should
            be able to locate this file in this directory 
            and continue re-enumerating for the new devices.

Issue:      After running the setup program and rebooting 
            the machine, Windows reports that it cannot find 
            one of the following files:
 
                  UHCD.SYS
                  USBD.SYS
                  USBHUB.SYS

Solution:   Click Browse in the dialog box where this 
            issue occurs, locate the

                  <Windows>\System32\drivers 
                  (for Windows* 98SE, Windows* Me)
                  
            directory, and click OK.  The system should
            be able to locate this file in this directory 
            and continue re-enumerating for the new devices.

Issue:      After running the setup program and rebooting 
            the machine, Windows reports that it cannot find 
            the following file:
                  isapnp.vxd

Solution:   Click Browse in the dialog box where this 
            issue occurs, locate the

                  <Windows>\System

            directory, and click OK.  The system should
            be able to locate this file in this directory 
            and continue re-enumerating for the new devices.

Issue:      After performing the silent install, the 
            HKLM\Software\Intel\InfInst key was not created 
            or the data of the value "install" is not 
            "success".

Solution:   This is caused by one of the following 
            scenarios:
               - The current system does not contain 
                 a supported operating system, or
               - The current system does not contain 
                 a supported chipset.

            Verify the System Requirements in Section 2.


************************************************************
* DISCLAIMER
************************************************************
Intel is making no claims of usability, efficacy or warranty.  
The Intel(R) SOFTWARE LICENSE AGREEMENT
(OEM / IHV / ISV Distribution & Single User) 
completely defines the licensed use of this software.
************************************************************
Information in this document is provided in connection with 
Intel(R) products.  No license, express or implied, by estoppel 
or otherwise, to any intellectual property rights is granted 
by this document.  Intel assumes no liability whatsoever, 
and Intel disclaims any express or implied warranty relating 
to sale and/or use of Intel(R) products, including liability 
or warranties relating to fitness for a particular purpose, 
merchantability or infringement of any patent, copyright or 
other intellectual property right.  Intel(R) products are 
not intended for use in medical, life saving, or 
life-sustaining applications.

************************************************************
Intel Corporation disclaims all warranties and liabilities 
for the use of this document and the information contained 
herein, and assumes no responsibility for any errors which 
may appear in this document, nor does Intel make a 
commitment to update the information contained herein.  
Intel reserves the right to make changes to this document at 
any time, without notice.
************************************************************
************************************************************

* Intel is a trademark or registered trademark of Intel Corporation 
  or its subsidiaries in the United States and other countries.
* Other brands and names are the property of their 
  respective owners.

Copyright (c) Intel Corporation, 1997-2003
